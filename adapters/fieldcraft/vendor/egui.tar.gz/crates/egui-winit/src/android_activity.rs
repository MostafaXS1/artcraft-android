//! Shared Android JNI plumbing for the `egui-winit` Android integrations.

#![cfg(target_os = "android")]

static ACTIVITY: std::sync::OnceLock<usize> = std::sync::OnceLock::new();
static VM: std::sync::OnceLock<usize> = std::sync::OnceLock::new();

pub fn set_activity(activity_as_ptr: *mut std::ffi::c_void) {
    let _ = ACTIVITY.set(activity_as_ptr as usize);
}

pub fn set_vm(vm_as_ptr: *mut std::ffi::c_void) {
    let _ = VM.set(vm_as_ptr as usize);
}

pub fn activity_raw() -> Option<jni::sys::jobject> {
    ACTIVITY.get().copied().map(|ptr| ptr as jni::sys::jobject)
}

pub fn vm_raw() -> Option<*mut jni::sys::JavaVM> {
    VM.get().copied().map(|ptr| ptr as *mut jni::sys::JavaVM)
}
