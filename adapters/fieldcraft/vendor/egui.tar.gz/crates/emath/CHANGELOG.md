# Changelog for emath
All notable changes to the `emath` crate will be noted in this file.


This file is updated upon each release.
Changes since the last release can be found at <https://github.com/emilk/egui/compare/latest...HEAD> or by running the `scripts/generate_changelog.py` script.


## 0.37.0 - 2026-10-15
* Add `Align2` helpers [#8485](https://github.com/emilk/egui/pull/8485) by [@lucasmerlin](https://github.com/lucasmerlin)
* Add `Rangef::union` [#8603](https://github.com/emilk/egui/pull/8603) by [@emilk](https://github.com/emilk)
* Feat: add utils methods to Rect (floor, round, ceil) [#8654](https://github.com/emilk/egui/pull/8654) by [@Its-Just-Nans](https://github.com/Its-Just-Nans)


## 0.36.2 - 2026-09-08
Nothing new


## 0.36.1 - 2026-08-07
Nothing new


## 0.36.0 - 2026-08-05
Nothing new


## 0.35.0 - 2026-06-25
Nothing new


## 0.34.3 - 2026-05-27
Nothing new


## 0.34.2 - 2026-05-04
Nothing new


## 0.34.1 - 2026-03-27
Nothing new


## 0.34.0 - 2026-03-26
Nothing new


## 0.33.3 - 2025-12-11
Nothing new


## 0.33.2 - 2025-11-13
* Fix edge cases in "smart aiming" in sliders [#7680](https://github.com/emilk/egui/pull/7680) by [@emilk](https://github.com/emilk)


## 0.33.0 - 2025-10-09
* Add `emath::fast_midpoint` [#7435](https://github.com/emilk/egui/pull/7435) by [@emilk](https://github.com/emilk)
* Generate changelogs for emath [#7513](https://github.com/emilk/egui/pull/7513) by [@lucasmerlin](https://github.com/lucasmerlin)
* Improve `OrderedFloat` hash performance [#7512](https://github.com/emilk/egui/pull/7512) by [@valadaptive](https://github.com/valadaptive)
* Update MSRV from 1.86 to 1.88 [#7579](https://github.com/emilk/egui/pull/7579) by [@Wumpf](https://github.com/Wumpf)

