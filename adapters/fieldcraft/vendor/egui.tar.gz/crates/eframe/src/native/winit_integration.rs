use std::{sync::Arc, time::Instant};

use winit::{
    event_loop::ActiveEventLoop,
    window::{Window, WindowId},
};

use egui::ViewportId;
#[cfg(feature = "accesskit")]
use egui_winit::accesskit_winit;

/// Returns `true` if the window is invisible or minimized.
///
/// These windows don't receive `RedrawRequested` events on Windows,
/// so they need special handling to keep processing viewport commands.
pub fn is_invisible_or_minimized(window: &Window) -> bool {
    window.is_visible() == Some(false) || window.is_minimized() == Some(true)
}

/// The repaint an event asks for, after the app's [`crate::App::repaint_on_window_event`]
/// override: `default` unless the app says otherwise. Only the root viewport's events are put
/// to the app (`viewport`, `None` when the window is unknown): the event carries no window, so
/// the app would read another window's pointer position as the root's.
pub(crate) fn repaint_for_event(
    app: &mut dyn crate::App,
    event: &winit::event::WindowEvent,
    default: bool,
    viewport: Option<ViewportId>,
) -> bool {
    if viewport != Some(ViewportId::ROOT) {
        return default;
    }
    app.repaint_on_window_event(event).unwrap_or(default)
}

/// [`repaint_for_event`] for a device event ([`crate::App::repaint_on_device_event`]), with
/// `viewport` the one the event was delivered to.
pub(crate) fn repaint_for_device_event(
    app: &mut dyn crate::App,
    event: &winit::event::DeviceEvent,
    default: bool,
    viewport: Option<ViewportId>,
) -> bool {
    if viewport != Some(ViewportId::ROOT) {
        return default;
    }
    app.repaint_on_device_event(event).unwrap_or(default)
}

#[cfg(test)]
mod tests {
    use super::{repaint_for_device_event, repaint_for_event};
    use egui::ViewportId;

    struct TestApp {
        answer: Option<bool>,
    }

    impl crate::App for TestApp {
        fn ui(&mut self, _ui: &mut egui::Ui, _frame: &mut crate::Frame) {}

        fn repaint_on_window_event(&mut self, _event: &winit::event::WindowEvent) -> Option<bool> {
            self.answer
        }

        fn repaint_on_device_event(&mut self, _event: &winit::event::DeviceEvent) -> Option<bool> {
            self.answer
        }
    }

    /// An app can suppress or force the repaint a window or device event of the root viewport
    /// asks for; `None` keeps the default. Another window's events keep the default.
    #[test]
    fn the_app_can_override_the_repaint_an_event_asks_for() {
        let window_event = winit::event::WindowEvent::Focused(true);
        let device_event = winit::event::DeviceEvent::MouseMotion { delta: (1.0, 2.0) };
        for (answer, default, expected) in [
            (None, true, true),
            (None, false, false),
            (Some(false), true, false),
            (Some(true), false, true),
        ] {
            let mut app = TestApp { answer };
            let root = Some(ViewportId::ROOT);
            assert_eq!(
                repaint_for_event(&mut app, &window_event, default, root),
                expected,
                "{answer:?} over {default} for a window event"
            );
            assert_eq!(
                repaint_for_device_event(&mut app, &device_event, default, root),
                expected,
                "{answer:?} over {default} for a device event"
            );
            for other in [Some(ViewportId::from_hash_of("panel")), None] {
                assert_eq!(
                    repaint_for_event(&mut app, &window_event, default, other),
                    default,
                    "{answer:?} for a window event of {other:?}"
                );
                assert_eq!(
                    repaint_for_device_event(&mut app, &device_event, default, other),
                    default,
                    "{answer:?} for a device event of {other:?}"
                );
            }
        }
    }
}

/// On Mac, a minimized window uses up all CPU:
/// <https://github.com/emilk/egui/issues/325>
///
/// On Windows, an invisible window also uses up all CPU:
/// <https://github.com/emilk/egui/issues/7776>
pub fn sleep_if_invisible_or_minimized(window: Option<&Window>) {
    if window.is_some_and(is_invisible_or_minimized) {
        profiling::scope!("minimized_sleep");
        std::thread::sleep(core::time::Duration::from_millis(10));
    }
}

/// What [`WinitApp::run_ui_and_paint`] runs.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum PassMode {
    /// Run [`crate::App::logic`], plus the ui and painting if the viewport is visible.
    Full,

    /// Run only [`crate::App::logic`]: no egui pass and no painting.
    ///
    /// Used when the window was asked to redraw, but the windowing system hasn't let it
    /// (e.g. a Wayland compositor withholding frame callbacks from a hidden window).
    LogicOnly,
}

/// Create an egui context, restoring it from storage if possible.
pub fn create_egui_context(storage: Option<&dyn crate::Storage>) -> egui::Context {
    profiling::function_scope!();

    pub const IS_DESKTOP: bool = cfg!(any(
        target_os = "freebsd",
        target_os = "linux",
        target_os = "macos",
        target_os = "openbsd",
        target_os = "windows",
    ));

    let egui_ctx = egui::Context::default();

    egui_ctx.set_embed_viewports(!IS_DESKTOP);

    egui_ctx.options_mut(|o| {
        // eframe supports multi-pass (Context::request_discard).
        #[expect(clippy::unwrap_used)]
        {
            o.max_passes = 2.try_into().unwrap();
        }
    });

    let memory = crate::native::epi_integration::load_egui_memory(storage).unwrap_or_default();
    egui_ctx.memory_mut(|mem| *mem = memory);

    egui_ctx
}

/// The custom even `eframe` uses with the [`winit`] event loop.
#[derive(Debug)]
pub enum UserEvent {
    /// A repaint is requested.
    RequestRepaint {
        /// What to repaint.
        viewport_id: ViewportId,

        /// When to repaint.
        when: Instant,

        /// What the cumulative pass number was when the repaint was _requested_.
        cumulative_pass_nr: u64,
    },

    /// A request related to [`accesskit`](https://accesskit.dev/).
    #[cfg(feature = "accesskit")]
    AccessKitActionRequest(accesskit_winit::Event),
}

#[cfg(feature = "accesskit")]
impl From<accesskit_winit::Event> for UserEvent {
    fn from(inner: accesskit_winit::Event) -> Self {
        Self::AccessKitActionRequest(inner)
    }
}

pub trait WinitApp {
    fn egui_ctx(&self) -> Option<&egui::Context>;

    fn window(&self, window_id: WindowId) -> Option<Arc<Window>>;

    fn window_id_from_viewport_id(&self, id: ViewportId) -> Option<WindowId>;

    fn save(&mut self);

    fn save_and_destroy(&mut self);

    fn run_ui_and_paint(
        &mut self,
        event_loop: &ActiveEventLoop,
        window_id: WindowId,
        mode: PassMode,
    ) -> crate::Result<EventResult>;

    fn suspended(&mut self, event_loop: &ActiveEventLoop) -> crate::Result<EventResult>;

    fn resumed(&mut self, event_loop: &ActiveEventLoop) -> crate::Result<EventResult>;

    fn device_event(
        &mut self,
        event_loop: &ActiveEventLoop,
        device_id: winit::event::DeviceId,
        event: winit::event::DeviceEvent,
    ) -> crate::Result<EventResult>;

    fn window_event(
        &mut self,
        event_loop: &ActiveEventLoop,
        window_id: WindowId,
        event: winit::event::WindowEvent,
    ) -> crate::Result<EventResult>;

    #[cfg(feature = "accesskit")]
    fn on_accesskit_event(&mut self, event: accesskit_winit::Event) -> crate::Result<EventResult>;
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum EventResult {
    Wait,

    /// Causes a synchronous repaint inside the event handler. This should only
    /// be used in special situations if the window must be repainted while
    /// handling a specific event. This occurs on Windows when handling resizes.
    ///
    /// `RepaintNow` creates a new frame synchronously, and should therefore
    /// only be used for extremely urgent repaints.
    RepaintNow(WindowId),

    /// Queues a repaint for once the event loop handles its next redraw. Exists
    /// so that multiple input events can be handled in one frame. Does not
    /// cause any delay like `RepaintNow`.
    RepaintNext(WindowId),

    RepaintAt(WindowId, Instant),

    /// Causes a save of the client state when the persistence feature is enabled.
    Save,

    /// Starts the process of ending eframe execution whilst allowing for proper
    /// clean up of resources.
    ///
    /// # Warning
    /// This event **must** occur before [`Exit`] to correctly exit eframe code.
    /// If in doubt, return this event.
    ///
    /// [`Exit`]: [EventResult::Exit]
    CloseRequested,

    /// The event loop will exit, now.
    /// The correct circumstance to return this event is in response to a winit "Destroyed" event.
    ///
    /// # Warning
    /// The [`CloseRequested`] **must** occur before this event to ensure that winit
    /// is able to remove any open windows. Otherwise the window(s) will remain open
    /// until the program terminates.
    ///
    /// [`CloseRequested`]: EventResult::CloseRequested
    Exit,
}

#[cfg(feature = "accesskit")]
pub(crate) fn on_accesskit_window_event(
    egui_winit: &mut egui_winit::State,
    window_id: WindowId,
    event: &accesskit_winit::WindowEvent,
) -> EventResult {
    match event {
        accesskit_winit::WindowEvent::InitialTreeRequested => {
            egui_winit.egui_ctx().enable_accesskit();
            // Because we can't provide the initial tree synchronously
            // (because that would require the activation handler to access
            // the same mutable state as the winit event handler), some
            // AccessKit platform adapters will use a placeholder tree
            // until we send the first tree update. To minimize the possible
            // bad effects of that workaround, repaint and send the tree
            // immediately.
            EventResult::RepaintNow(window_id)
        }
        accesskit_winit::WindowEvent::ActionRequested(request) => {
            egui_winit.on_accesskit_action_request(request.clone());
            // As a form of user input, accessibility actions should cause
            // a repaint, but not until the next regular frame.
            EventResult::RepaintNext(window_id)
        }
        accesskit_winit::WindowEvent::AccessibilityDeactivated => {
            egui_winit.egui_ctx().disable_accesskit();
            // Disabling AccessKit support should have no visible effect,
            // so there's no need to repaint.
            EventResult::Wait
        }
    }
}
