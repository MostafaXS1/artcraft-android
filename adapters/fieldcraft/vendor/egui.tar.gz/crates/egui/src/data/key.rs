/// Keyboard keys.
///
/// egui usually uses logical keys, i.e. after applying any user keymap.\
// See comment at the end of `Key { … }` on how to add new keys.
#[derive(Clone, Copy, Debug, Eq, Ord, PartialEq, PartialOrd, Hash)]
#[cfg_attr(feature = "serde", derive(serde::Deserialize, serde::Serialize))]
pub enum Key {
    // ----------------------------------------------
    // Commands:
    ArrowDown,
    ArrowLeft,
    ArrowRight,
    ArrowUp,

    Escape,
    Tab,
    Backspace,
    Enter,
    Space,

    Insert,
    Delete,
    Home,
    End,
    PageUp,
    PageDown,

    Copy,
    Cut,
    Paste,

    // ----------------------------------------------
    // Punctuation:
    /// `:`
    Colon,

    /// `,`
    Comma,

    /// `\`
    Backslash,

    /// `/`
    Slash,

    /// `|`, a vertical bar
    Pipe,

    /// `?`
    Questionmark,

    // '!'
    Exclamationmark,

    // `[`
    OpenBracket,

    // `]`
    CloseBracket,

    // `{`
    OpenCurlyBracket,

    // `}`
    CloseCurlyBracket,

    /// Also known as "backquote" or "grave"
    Backtick,

    /// `-`
    Minus,

    /// `.`
    Period,

    /// `+`
    Plus,

    /// `=`
    Equals,

    /// `;`
    Semicolon,

    /// `'`
    Quote,

    // ----------------------------------------------
    // Digits:
    /// `0` (from main row or numpad)
    Num0,

    /// `1` (from main row or numpad)
    Num1,

    /// `2` (from main row or numpad)
    Num2,

    /// `3` (from main row or numpad)
    Num3,

    /// `4` (from main row or numpad)
    Num4,

    /// `5` (from main row or numpad)
    Num5,

    /// `6` (from main row or numpad)
    Num6,

    /// `7` (from main row or numpad)
    Num7,

    /// `8` (from main row or numpad)
    Num8,

    /// `9` (from main row or numpad)
    Num9,

    // ----------------------------------------------
    // Letters:
    A, // Used for cmd+A (select All)
    B,
    C, // |CMD COPY|
    D, // |CMD BOOKMARK|
    E, // |CMD SEARCH|
    F, // |CMD FIND firefox & chrome|
    G, // |CMD FIND chrome|
    H, // |CMD History|
    I, // italics
    J, // |CMD SEARCH firefox/DOWNLOAD chrome|
    K, // Used for ctrl+K (delete text after cursor)
    L,
    M,
    N,
    O, // |CMD OPEN|
    P, // |CMD PRINT|
    Q,
    R, // |CMD REFRESH|
    S, // |CMD SAVE|
    T, // |CMD TAB|
    U, // Used for ctrl+U (delete text before cursor)
    V, // |CMD PASTE|
    W, // Used for ctrl+W (delete previous word)
    X, // |CMD CUT|
    Y,
    Z, // |CMD UNDO|

    // ----------------------------------------------
    // Function keys:
    F1,
    F2,
    F3,
    F4,
    F5, // |CMD REFRESH|
    F6,
    F7,
    F8,
    F9,
    F10,
    F11,
    F12,
    F13,
    F14,
    F15,
    F16,
    F17,
    F18,
    F19,
    F20,
    F21,
    F22,
    F23,
    F24,
    F25,
    F26,
    F27,
    F28,
    F29,
    F30,
    F31,
    F32,
    F33,
    F34,
    F35,

    // ----------------------------------------------
    // Browser / multimedia navigation keys:
    /// Back navigation key from multimedia keyboard.
    /// Android sends this key on Back button press.
    /// Does not work on Web.
    BrowserBack,

    /// Forward navigation key.
    BrowserForward,

    /// Refresh / reload page key.
    BrowserRefresh,

    /// Search key.
    BrowserSearch,

    /// Go to home page key.
    BrowserHome,

    /// Open favorites / bookmarks key.
    BrowserFavorites,

    /// Stop loading key.
    BrowserStop,

    // ----------------------------------------------
    // Media control keys:
    /// Play / Pause toggle key.
    MediaPlayPause,

    /// Next track key.
    MediaTrackNext,

    /// Previous track key.
    MediaTrackPrevious,

    /// Stop playback key.
    MediaStop,

    /// Mute audio toggle key.
    AudioVolumeMute,

    /// Decrease audio volume key.
    AudioVolumeDown,

    /// Increase audio volume key.
    AudioVolumeUp,

    // ----------------------------------------------
    // Launch keys:
    /// Launch mail application key.
    LaunchMail,

    /// Launch application 1 (typically "My Computer") key.
    LaunchApp1,

    /// Launch application 2 (typically "Calculator") key.
    LaunchApp2,

    // ----------------------------------------------
    // Modifier keys (exposed as distinct left/right variants so that
    // games and input-capture UIs can bind them independently). egui's
    // `Modifiers` struct still collapses both sides for the common case
    // (e.g. "Ctrl+C"); these variants are emitted only as physical
    // `Event::Key` presses.
    /// Left Shift key.
    ShiftLeft,

    /// Right Shift key.
    ShiftRight,

    /// Left Control key.
    ControlLeft,

    /// Right Control key.
    ControlRight,

    /// Left Alt / Option key.
    AltLeft,

    /// Right Alt / `AltGr` / Option key.
    AltRight,

    /// Left Super / Meta / Command / Windows key.
    SuperLeft,

    /// Right Super / Meta / Command / Windows key.
    SuperRight,

    // ----------------------------------------------
    // International keys — physical positions that only exist on
    // non-US keyboards.
    /// ISO 102nd key: physically located between the left Shift and Z
    /// on ISO layouts. On French AZERTY it produces `<>|`; on UK
    /// QWERTY a secondary `\` / `|`. Missing from US ANSI keyboards.
    IntlBackslash,

    // ----------------------------------------------
    // Lock / System keys:
    /// Caps Lock key.
    CapsLock,

    /// Num Lock key.
    NumLock,

    /// Scroll Lock key.
    ScrollLock,

    /// Print Screen / `SysRq` key.
    PrintScreen,

    /// Pause / Break key.
    Pause,

    /// Menu / Apps key (opens context menu).
    Menu,

    // ----------------------------------------------
    // Mac / other system keys:
    /// Fn / Globe key (Mac keyboard function key).
    Fn,

    /// Eject key (⏏) on Mac keyboards.
    Eject,

    /// Help key (found on older PC and Mac keyboards).
    Help,

    /// Power key (toggles power state).
    Power,

    /// Sleep / Standby key.
    Sleep,

    /// Clear key (on some keyboards/numpads).
    Clear,
    // When adding keys, remember to also update:
    // * crates/egui-winit/src/lib.rs
    // * Key::ALL
    // * Key::from_name
    // You should test that it works using the "Input Event History" window in the egui demo app.
    // Make sure to test both natively and on web!
    // Also: don't add keys last; add them to the group they best belong to.
}

impl Key {
    /// All egui keys
    pub const ALL: &'static [Self] = &[
        // Commands:
        Self::ArrowDown,
        Self::ArrowLeft,
        Self::ArrowRight,
        Self::ArrowUp,
        Self::Escape,
        Self::Tab,
        Self::Backspace,
        Self::Enter,
        Self::Insert,
        Self::Delete,
        Self::Home,
        Self::End,
        Self::PageUp,
        Self::PageDown,
        Self::Copy,
        Self::Cut,
        Self::Paste,
        // Punctuation:
        Self::Space,
        Self::Colon,
        Self::Comma,
        Self::Minus,
        Self::Period,
        Self::Plus,
        Self::Equals,
        Self::Semicolon,
        Self::OpenBracket,
        Self::CloseBracket,
        Self::OpenCurlyBracket,
        Self::CloseCurlyBracket,
        Self::Backtick,
        Self::Backslash,
        Self::Slash,
        Self::Pipe,
        Self::Questionmark,
        Self::Exclamationmark,
        Self::Quote,
        // Digits:
        Self::Num0,
        Self::Num1,
        Self::Num2,
        Self::Num3,
        Self::Num4,
        Self::Num5,
        Self::Num6,
        Self::Num7,
        Self::Num8,
        Self::Num9,
        // Letters:
        Self::A,
        Self::B,
        Self::C,
        Self::D,
        Self::E,
        Self::F,
        Self::G,
        Self::H,
        Self::I,
        Self::J,
        Self::K,
        Self::L,
        Self::M,
        Self::N,
        Self::O,
        Self::P,
        Self::Q,
        Self::R,
        Self::S,
        Self::T,
        Self::U,
        Self::V,
        Self::W,
        Self::X,
        Self::Y,
        Self::Z,
        // Function keys:
        Self::F1,
        Self::F2,
        Self::F3,
        Self::F4,
        Self::F5,
        Self::F6,
        Self::F7,
        Self::F8,
        Self::F9,
        Self::F10,
        Self::F11,
        Self::F12,
        Self::F13,
        Self::F14,
        Self::F15,
        Self::F16,
        Self::F17,
        Self::F18,
        Self::F19,
        Self::F20,
        Self::F21,
        Self::F22,
        Self::F23,
        Self::F24,
        Self::F25,
        Self::F26,
        Self::F27,
        Self::F28,
        Self::F29,
        Self::F30,
        Self::F31,
        Self::F32,
        Self::F33,
        Self::F34,
        Self::F35,
        // Navigation keys:
        Self::BrowserBack,
        Self::BrowserForward,
        Self::BrowserRefresh,
        Self::BrowserSearch,
        Self::BrowserHome,
        Self::BrowserFavorites,
        Self::BrowserStop,
        // Media control keys:
        Self::MediaPlayPause,
        Self::MediaTrackNext,
        Self::MediaTrackPrevious,
        Self::MediaStop,
        Self::AudioVolumeMute,
        Self::AudioVolumeDown,
        Self::AudioVolumeUp,
        // Launch keys:
        Self::LaunchMail,
        Self::LaunchApp1,
        Self::LaunchApp2,
        // Modifier keys (physical L/R):
        Self::ShiftLeft,
        Self::ShiftRight,
        Self::ControlLeft,
        Self::ControlRight,
        Self::AltLeft,
        Self::AltRight,
        Self::SuperLeft,
        Self::SuperRight,
        // International keys:
        Self::IntlBackslash,
        // Lock / System keys:
        Self::CapsLock,
        Self::NumLock,
        Self::ScrollLock,
        Self::PrintScreen,
        Self::Pause,
        Self::Menu,
        // Mac / other system keys:
        Self::Fn,
        Self::Eject,
        Self::Help,
        Self::Power,
        Self::Sleep,
        Self::Clear,
    ];

    /// Converts `"A"` to `Key::A`, `Space` to `Key::Space`, etc.
    ///
    /// Makes sense for logical keys.
    ///
    /// This will parse the output of both [`Self::name`] and [`Self::symbol_or_name`],
    /// but will also parse single characters, so that both `"-"` and `"Minus"` will return `Key::Minus`.
    ///
    /// This should support both the names generated in a web browser,
    /// and by winit. Please test on both with `eframe`.
    pub fn from_name(key: &str) -> Option<Self> {
        Some(match key {
            "⏷" | "ArrowDown" | "Down" => Self::ArrowDown,
            "⏴" | "ArrowLeft" | "Left" => Self::ArrowLeft,
            "⏵" | "ArrowRight" | "Right" => Self::ArrowRight,
            "⏶" | "ArrowUp" | "Up" => Self::ArrowUp,

            "Escape" | "Esc" => Self::Escape,
            "Tab" => Self::Tab,
            "Backspace" => Self::Backspace,
            "Enter" | "Return" | "NumpadEnter" => Self::Enter,

            "Insert" => Self::Insert,
            "Delete" => Self::Delete,
            "Home" => Self::Home,
            "End" => Self::End,
            "PageUp" => Self::PageUp,
            "PageDown" => Self::PageDown,

            "Copy" => Self::Copy,
            "Cut" => Self::Cut,
            "Paste" => Self::Paste,

            " " | "Space" => Self::Space,
            ":" | "Colon" => Self::Colon,
            "," | "Comma" | "NumpadComma" => Self::Comma,
            "-" | "−" | "Minus" | "NumpadSubtract" => Self::Minus,
            "." | "Period" | "NumpadDecimal" => Self::Period,
            "+" | "Plus" | "NumpadAdd" => Self::Plus,
            "=" | "Equal" | "Equals" | "NumpadEqual" => Self::Equals,
            ";" | "Semicolon" => Self::Semicolon,
            "\\" | "Backslash" => Self::Backslash,
            "/" | "Slash" | "NumpadDivide" => Self::Slash,
            "|" | "Pipe" => Self::Pipe,
            "?" | "Questionmark" => Self::Questionmark,
            "!" | "Exclamationmark" => Self::Exclamationmark,
            "[" | "OpenBracket" | "BracketLeft" => Self::OpenBracket,
            "]" | "CloseBracket" | "BracketRight" => Self::CloseBracket,
            "{" | "OpenCurlyBracket" => Self::OpenCurlyBracket,
            "}" | "CloseCurlyBracket" => Self::CloseCurlyBracket,
            "`" | "Backtick" | "Backquote" | "Grave" => Self::Backtick,
            "'" | "Quote" => Self::Quote,

            "0" | "Digit0" | "Numpad0" => Self::Num0,
            "1" | "Digit1" | "Numpad1" => Self::Num1,
            "2" | "Digit2" | "Numpad2" => Self::Num2,
            "3" | "Digit3" | "Numpad3" => Self::Num3,
            "4" | "Digit4" | "Numpad4" => Self::Num4,
            "5" | "Digit5" | "Numpad5" => Self::Num5,
            "6" | "Digit6" | "Numpad6" => Self::Num6,
            "7" | "Digit7" | "Numpad7" => Self::Num7,
            "8" | "Digit8" | "Numpad8" => Self::Num8,
            "9" | "Digit9" | "Numpad9" => Self::Num9,

            "a" | "A" | "KeyA" => Self::A,
            "b" | "B" | "KeyB" => Self::B,
            "c" | "C" | "KeyC" => Self::C,
            "d" | "D" | "KeyD" => Self::D,
            "e" | "E" | "KeyE" => Self::E,
            "f" | "F" | "KeyF" => Self::F,
            "g" | "G" | "KeyG" => Self::G,
            "h" | "H" | "KeyH" => Self::H,
            "i" | "I" | "KeyI" => Self::I,
            "j" | "J" | "KeyJ" => Self::J,
            "k" | "K" | "KeyK" => Self::K,
            "l" | "L" | "KeyL" => Self::L,
            "m" | "M" | "KeyM" => Self::M,
            "n" | "N" | "KeyN" => Self::N,
            "o" | "O" | "KeyO" => Self::O,
            "p" | "P" | "KeyP" => Self::P,
            "q" | "Q" | "KeyQ" => Self::Q,
            "r" | "R" | "KeyR" => Self::R,
            "s" | "S" | "KeyS" => Self::S,
            "t" | "T" | "KeyT" => Self::T,
            "u" | "U" | "KeyU" => Self::U,
            "v" | "V" | "KeyV" => Self::V,
            "w" | "W" | "KeyW" => Self::W,
            "x" | "X" | "KeyX" => Self::X,
            "y" | "Y" | "KeyY" => Self::Y,
            "z" | "Z" | "KeyZ" => Self::Z,

            "F1" => Self::F1,
            "F2" => Self::F2,
            "F3" => Self::F3,
            "F4" => Self::F4,
            "F5" => Self::F5,
            "F6" => Self::F6,
            "F7" => Self::F7,
            "F8" => Self::F8,
            "F9" => Self::F9,
            "F10" => Self::F10,
            "F11" => Self::F11,
            "F12" => Self::F12,
            "F13" => Self::F13,
            "F14" => Self::F14,
            "F15" => Self::F15,
            "F16" => Self::F16,
            "F17" => Self::F17,
            "F18" => Self::F18,
            "F19" => Self::F19,
            "F20" => Self::F20,
            "F21" => Self::F21,
            "F22" => Self::F22,
            "F23" => Self::F23,
            "F24" => Self::F24,
            "F25" => Self::F25,
            "F26" => Self::F26,
            "F27" => Self::F27,
            "F28" => Self::F28,
            "F29" => Self::F29,
            "F30" => Self::F30,
            "F31" => Self::F31,
            "F32" => Self::F32,
            "F33" => Self::F33,
            "F34" => Self::F34,
            "F35" => Self::F35,

            "BrowserBack" => Self::BrowserBack,
            "BrowserForward" => Self::BrowserForward,
            "BrowserRefresh" => Self::BrowserRefresh,
            "BrowserSearch" => Self::BrowserSearch,
            "BrowserHome" => Self::BrowserHome,
            "BrowserFavorites" => Self::BrowserFavorites,
            "BrowserStop" => Self::BrowserStop,

            "MediaPlayPause" => Self::MediaPlayPause,
            "MediaTrackNext" => Self::MediaTrackNext,
            "MediaTrackPrevious" => Self::MediaTrackPrevious,
            "MediaStop" => Self::MediaStop,
            "AudioVolumeMute" => Self::AudioVolumeMute,
            "AudioVolumeDown" => Self::AudioVolumeDown,
            "AudioVolumeUp" => Self::AudioVolumeUp,

            "LaunchMail" => Self::LaunchMail,
            "LaunchApp1" => Self::LaunchApp1,
            "LaunchApp2" => Self::LaunchApp2,

            "ShiftLeft" => Self::ShiftLeft,
            "ShiftRight" => Self::ShiftRight,
            "ControlLeft" => Self::ControlLeft,
            "ControlRight" => Self::ControlRight,
            "AltLeft" => Self::AltLeft,
            "AltRight" => Self::AltRight,

            "SuperLeft" | "MetaLeft" | "OSLeft" => Self::SuperLeft,
            "SuperRight" | "MetaRight" | "OSRight" => Self::SuperRight,

            "IntlBackslash" => Self::IntlBackslash,

            "CapsLock" => Self::CapsLock,
            "NumLock" => Self::NumLock,
            "ScrollLock" => Self::ScrollLock,
            "PrintScreen" => Self::PrintScreen,
            "Pause" => Self::Pause,
            "ContextMenu" | "Menu" | "Apps" => Self::Menu,

            "Fn" | "FnLock" | "Globe" => Self::Fn,
            "Eject" => Self::Eject,
            "Help" => Self::Help,
            "Power" => Self::Power,
            "Sleep" | "Standby" => Self::Sleep,
            "Clear" => Self::Clear,

            _ => return None,
        })
    }

    /// Emoji or name representing the key
    pub fn symbol_or_name(self) -> &'static str {
        // TODO(emilk): add support for more unicode symbols (see for instance https://wincent.com/wiki/Unicode_representations_of_modifier_keys).
        // Before we do we must first make sure they are supported in `Fonts` though,
        // so perhaps this functions needs to take a `supports_character: impl Fn(char) -> bool` or something.
        match self {
            Self::ArrowDown => "⏷",
            Self::ArrowLeft => "⏴",
            Self::ArrowRight => "⏵",
            Self::ArrowUp => "⏶",

            Self::Colon => ":",
            Self::Comma => ",",
            Self::Minus => crate::MINUS_CHAR_STR,
            Self::Period => ".",
            Self::Plus => "+",
            Self::Equals => "=",
            Self::Semicolon => ";",
            Self::Backslash => "\\",
            Self::Slash => "/",
            Self::Pipe => "|",
            Self::Questionmark => "?",
            Self::Exclamationmark => "!",
            Self::OpenBracket => "[",
            Self::CloseBracket => "]",
            Self::OpenCurlyBracket => "{",
            Self::CloseCurlyBracket => "}",
            Self::Backtick => "`",

            _ => self.name(),
        }
    }

    /// Human-readable English name.
    pub fn name(self) -> &'static str {
        match self {
            Self::ArrowDown => "Down",
            Self::ArrowLeft => "Left",
            Self::ArrowRight => "Right",
            Self::ArrowUp => "Up",

            Self::Escape => "Escape",
            Self::Tab => "Tab",
            Self::Backspace => "Backspace",
            Self::Enter => "Enter",

            Self::Insert => "Insert",
            Self::Delete => "Delete",
            Self::Home => "Home",
            Self::End => "End",
            Self::PageUp => "PageUp",
            Self::PageDown => "PageDown",

            Self::Copy => "Copy",
            Self::Cut => "Cut",
            Self::Paste => "Paste",

            Self::Space => "Space",
            Self::Colon => "Colon",
            Self::Comma => "Comma",
            Self::Minus => "Minus",
            Self::Period => "Period",
            Self::Plus => "Plus",
            Self::Equals => "Equals",
            Self::Semicolon => "Semicolon",
            Self::Backslash => "Backslash",
            Self::Slash => "Slash",
            Self::Pipe => "Pipe",
            Self::Questionmark => "Questionmark",
            Self::Exclamationmark => "Exclamationmark",
            Self::OpenBracket => "OpenBracket",
            Self::CloseBracket => "CloseBracket",
            Self::OpenCurlyBracket => "OpenCurlyBracket",
            Self::CloseCurlyBracket => "CloseCurlyBracket",
            Self::Backtick => "Backtick",
            Self::Quote => "Quote",

            Self::Num0 => "0",
            Self::Num1 => "1",
            Self::Num2 => "2",
            Self::Num3 => "3",
            Self::Num4 => "4",
            Self::Num5 => "5",
            Self::Num6 => "6",
            Self::Num7 => "7",
            Self::Num8 => "8",
            Self::Num9 => "9",

            Self::A => "A",
            Self::B => "B",
            Self::C => "C",
            Self::D => "D",
            Self::E => "E",
            Self::F => "F",
            Self::G => "G",
            Self::H => "H",
            Self::I => "I",
            Self::J => "J",
            Self::K => "K",
            Self::L => "L",
            Self::M => "M",
            Self::N => "N",
            Self::O => "O",
            Self::P => "P",
            Self::Q => "Q",
            Self::R => "R",
            Self::S => "S",
            Self::T => "T",
            Self::U => "U",
            Self::V => "V",
            Self::W => "W",
            Self::X => "X",
            Self::Y => "Y",
            Self::Z => "Z",
            Self::F1 => "F1",
            Self::F2 => "F2",
            Self::F3 => "F3",
            Self::F4 => "F4",
            Self::F5 => "F5",
            Self::F6 => "F6",
            Self::F7 => "F7",
            Self::F8 => "F8",
            Self::F9 => "F9",
            Self::F10 => "F10",
            Self::F11 => "F11",
            Self::F12 => "F12",
            Self::F13 => "F13",
            Self::F14 => "F14",
            Self::F15 => "F15",
            Self::F16 => "F16",
            Self::F17 => "F17",
            Self::F18 => "F18",
            Self::F19 => "F19",
            Self::F20 => "F20",
            Self::F21 => "F21",
            Self::F22 => "F22",
            Self::F23 => "F23",
            Self::F24 => "F24",
            Self::F25 => "F25",
            Self::F26 => "F26",
            Self::F27 => "F27",
            Self::F28 => "F28",
            Self::F29 => "F29",
            Self::F30 => "F30",
            Self::F31 => "F31",
            Self::F32 => "F32",
            Self::F33 => "F33",
            Self::F34 => "F34",
            Self::F35 => "F35",

            Self::BrowserBack => "BrowserBack",
            Self::BrowserForward => "BrowserForward",
            Self::BrowserRefresh => "BrowserRefresh",
            Self::BrowserSearch => "BrowserSearch",
            Self::BrowserHome => "BrowserHome",
            Self::BrowserFavorites => "BrowserFavorites",
            Self::BrowserStop => "BrowserStop",

            Self::MediaPlayPause => "MediaPlayPause",
            Self::MediaTrackNext => "MediaTrackNext",
            Self::MediaTrackPrevious => "MediaTrackPrevious",
            Self::MediaStop => "MediaStop",
            Self::AudioVolumeMute => "AudioVolumeMute",
            Self::AudioVolumeDown => "AudioVolumeDown",
            Self::AudioVolumeUp => "AudioVolumeUp",

            Self::LaunchMail => "LaunchMail",
            Self::LaunchApp1 => "LaunchApp1",
            Self::LaunchApp2 => "LaunchApp2",

            Self::ShiftLeft => "ShiftLeft",
            Self::ShiftRight => "ShiftRight",
            Self::ControlLeft => "ControlLeft",
            Self::ControlRight => "ControlRight",
            Self::AltLeft => "AltLeft",
            Self::AltRight => "AltRight",
            Self::SuperLeft => "SuperLeft",
            Self::SuperRight => "SuperRight",

            Self::IntlBackslash => "IntlBackslash",

            Self::CapsLock => "CapsLock",
            Self::NumLock => "NumLock",
            Self::ScrollLock => "ScrollLock",
            Self::PrintScreen => "PrintScreen",
            Self::Pause => "Pause",
            Self::Menu => "Menu",

            Self::Fn => "Fn",
            Self::Eject => "Eject",
            Self::Help => "Help",
            Self::Power => "Power",
            Self::Sleep => "Sleep",
            Self::Clear => "Clear",
        }
    }
}

#[test]
fn test_key_from_name() {
    assert_eq!(
        Key::ALL.len(),
        Key::Clear as usize + 1,
        "Some keys are missing in Key::ALL"
    );

    for &key in Key::ALL {
        let name = key.name();
        assert_eq!(
            Key::from_name(name),
            Some(key),
            "Failed to roundtrip {key:?} from name {name:?}"
        );

        let symbol = key.symbol_or_name();
        assert_eq!(
            Key::from_name(symbol),
            Some(key),
            "Failed to roundtrip {key:?} from symbol {symbol:?}"
        );
    }
}
