# Changelog for egui_kittest
All notable changes to the `egui_kittest` crate will be noted in this file.


This file is updated upon each release.
Changes since the last release can be found at <https://github.com/emilk/egui/compare/latest...HEAD> or by running the `scripts/generate_changelog.py` script.


## 0.37.0 - 2026-10-15
### ⭐ Added
* Add `diagnostic_max_steps` for a better`ExceededMaxStepsError` [#8421](https://github.com/emilk/egui/pull/8421) by [@lucasmerlin](https://github.com/lucasmerlin)
* Record egui_kittest tests as mp4s via `KITTEST_RECORD=1` [#8118](https://github.com/emilk/egui/pull/8118) by [@lucasmerlin](https://github.com/lucasmerlin)
* Add `HarnessBuilder::with_render_cursor` [#8551](https://github.com/emilk/egui/pull/8551) by [@lucasmerlin](https://github.com/lucasmerlin)
* Add `HarnessBuilder::with_context_setup` to configure the `Context` before the first pass [#8686](https://github.com/emilk/egui/pull/8686) by [@emilk](https://github.com/emilk)

### 🔧 Changed
* Fail kittest tests when an input widget has no accessible name [#8589](https://github.com/emilk/egui/pull/8589) by [@emilk](https://github.com/emilk)
* Draw tofu for families without fonts, and add `MissingGlyphPolicy` (panics by default in `egui_kittest`) [#8601](https://github.com/emilk/egui/pull/8601) by [@emilk](https://github.com/emilk)
* Apply `set_fonts`/`add_font` right away when no font is loaded yet [#8602](https://github.com/emilk/egui/pull/8602) by [@emilk](https://github.com/emilk)
* A read-only text field needs no accessible name [#8611](https://github.com/emilk/egui/pull/8611) by [@emilk](https://github.com/emilk)

### 🐛 Fixed
* Make kittest's predictable texture filtering honor `TextureOptions::NEAREST` [#8441](https://github.com/emilk/egui/pull/8441) by [@emilk](https://github.com/emilk)


## 0.36.2 - 2026-09-08
* Add new `render_every_step` flag to egui_kittest [#8487](https://github.com/emilk/egui/pull/8487) by [@lucasmerlin](https://github.com/lucasmerlin)


## 0.36.1 - 2026-08-07
Nothing new


## 0.36.0 - 2026-08-05
* Handle `ViewportCommand::InnerSize` in `egui_kittest` [#8350](https://github.com/emilk/egui/pull/8350) by [@lucasmerlin](https://github.com/lucasmerlin)
* Report failing pixels by threshold when a kittest snapshot fails [#8360](https://github.com/emilk/egui/pull/8360) by [@emilk](https://github.com/emilk)
* Rename `failed_pixel_count_threshold` to `max_failed_pixels` [#8383](https://github.com/emilk/egui/pull/8383) by [@emilk](https://github.com/emilk)


## 0.35.0 - 2026-06-25
* Add `HarnessBuilder::with_render_options()` (closes #7630) [#8060](https://github.com/emilk/egui/pull/8060) by [@MichaelGrupp](https://github.com/MichaelGrupp)
* Add `Harness::spawn_eframe_app` [#8120](https://github.com/emilk/egui/pull/8120) by [@emilk](https://github.com/emilk)
* Exclude `take_app` from `wasm32` in `egui_kittest` [#8178](https://github.com/emilk/egui/pull/8178) by [@grtlr](https://github.com/grtlr)
* Handle `ViewportCommand::Screenshot` in kittest [#8256](https://github.com/emilk/egui/pull/8256) by [@lucasmerlin](https://github.com/lucasmerlin)


## 0.34.3 - 2026-05-27
Nothing new


## 0.34.2 - 2026-05-04
Nothing new


## 0.34.1 - 2026-03-27
Nothing new


## 0.34.0 - 2026-03-26
* Turn `HarnessBuilder::with_options` into a proper builder method [#7697](https://github.com/emilk/egui/pull/7697) by [@emilk](https://github.com/emilk)
* Paint mouse cursor in kittest snapshot images [#7721](https://github.com/emilk/egui/pull/7721) by [@emilk](https://github.com/emilk)
* Add `kittest.toml` config file [#7643](https://github.com/emilk/egui/pull/7643) by [@lucasmerlin](https://github.com/lucasmerlin)
* Close debug_open_snapshot temp file before viewing it [#7841](https://github.com/emilk/egui/pull/7841) by [@yuriks](https://github.com/yuriks)


## 0.33.3 - 2025-12-11
* Enforce consistent snapshot updates [#7744](https://github.com/emilk/egui/pull/7744) by [@lucasmerlin](https://github.com/lucasmerlin)
* `kittest`: add drag-and-drop helpers [#7690](https://github.com/emilk/egui/pull/7690) by [@emilk](https://github.com/emilk)


## 0.33.2 - 2025-11-13
Nothing new


## 0.33.1 - 2025-10-15
* Add `egui_kittest::HarnessBuilder::with_options` [#7638](https://github.com/emilk/egui/pull/7638) by [@emilk](https://github.com/emilk)


## 0.33.0 - 2025-10-09
### ⭐ Added
* Kittest: Add `UPDATE_SNAPSHOTS=force` [#7508](https://github.com/emilk/egui/pull/7508) by [@emilk](https://github.com/emilk)
* Add `egui_kittest::HarnessBuilder::with_os` and set the default to `Nix` [#7493](https://github.com/emilk/egui/pull/7493) by [@lucasmerlin](https://github.com/lucasmerlin)
* Add `Harness::debug_open_snapshot` helper [#7590](https://github.com/emilk/egui/pull/7590) by [@lucasmerlin](https://github.com/lucasmerlin)

### 🔧 Changed
* Include popups and tooltips in `Harness::fit_contents` [#7556](https://github.com/emilk/egui/pull/7556) by [@oxkitsune](https://github.com/oxkitsune)
* Adjust when we write .diff and .new snapshot images [#7571](https://github.com/emilk/egui/pull/7571) by [@emilk](https://github.com/emilk)
* Update MSRV from 1.86 to 1.88 [#7579](https://github.com/emilk/egui/pull/7579) by [@Wumpf](https://github.com/Wumpf)
* `Harness`: Add `remove_cursor`,  `event` and `event_modifiers` [#7607](https://github.com/emilk/egui/pull/7607) by [@lucasmerlin](https://github.com/lucasmerlin)
* Use software texture filtering in kittest [#7602](https://github.com/emilk/egui/pull/7602) by [@emilk](https://github.com/emilk)
* Write .new.png file if snapshot is missing [#7610](https://github.com/emilk/egui/pull/7610) by [@lucasmerlin](https://github.com/lucasmerlin)

### 🔥 Removed
* Remove deprecated `Harness::wgpu_snapshot` and related fns [#7504](https://github.com/emilk/egui/pull/7504) by [@bircni](https://github.com/bircni)


## 0.32.3 - 2025-09-12
Nothing new


## 0.32.2 - 2025-09-04
* Allow masking widgets in kittest snapshots [#7467](https://github.com/emilk/egui/pull/7467) by [@lucasmerlin](https://github.com/lucasmerlin)


## 0.32.1 - 2025-08-15
* Fix `UPDATE_SNAPSHOTS`: only update if we didn't pass the test [#7455](https://github.com/emilk/egui/pull/7455) by [@emilk](https://github.com/emilk)


## 0.32.0 - 2025-07-10
### ⭐ Added
* Add `ImageLoader::has_pending` and `wait_for_pending_images` [#7030](https://github.com/emilk/egui/pull/7030) by [@lucasmerlin](https://github.com/lucasmerlin)
* Create custom `egui_kittest::Node` [#7138](https://github.com/emilk/egui/pull/7138) by [@lucasmerlin](https://github.com/lucasmerlin)
* Add `HarnessBuilder::theme` [#7289](https://github.com/emilk/egui/pull/7289) by [@emilk](https://github.com/emilk)
* Add support for scrolling via accesskit / kittest [#7286](https://github.com/emilk/egui/pull/7286) by [@lucasmerlin](https://github.com/lucasmerlin)
* Add `failed_pixel_count_threshold` [#7092](https://github.com/emilk/egui/pull/7092) by [@bircni](https://github.com/bircni)

### 🔧 Changed
* More ergonomic functions taking `Impl Into<String>` [#7307](https://github.com/emilk/egui/pull/7307) by [@emlik](https://github.com/emilk)
* Update kittest to 0.2 [#7332](https://github.com/emilk/egui/pull/7332) by [@lucasmerlin](https://github.com/lucasmerlin)


## 0.31.1 - 2025-03-05
* Fix modifiers not working in kittest [#5693](https://github.com/emilk/egui/pull/5693) by [@lucasmerlin](https://github.com/lucasmerlin)
* Enable all features for egui_kittest docs [#5711](https://github.com/emilk/egui/pull/5711) by [@YgorSouza](https://github.com/YgorSouza)
* Run a frame per queued event in egui_kittest [#5704](https://github.com/emilk/egui/pull/5704) by [@lucasmerlin](https://github.com/lucasmerlin)
* Add guidelines for image comparison tests [#5714](https://github.com/emilk/egui/pull/5714) by [@Wumpf](https://github.com/Wumpf)


## 0.31.0 - 2025-02-04
### ⭐ Added
* Add `Harness::new_eframe` and `TestRenderer` trait [#5539](https://github.com/emilk/egui/pull/5539) by [@lucasmerlin](https://github.com/lucasmerlin)
* Change `Harness::run` to run until no more repaints are requested [#5580](https://github.com/emilk/egui/pull/5580) by [@lucasmerlin](https://github.com/lucasmerlin)
* Add `SnapshotResults` struct to `egui_kittest` [#5672](https://github.com/emilk/egui/pull/5672) by [@lucasmerlin](https://github.com/lucasmerlin)

### 🔧 Changed
* Extend `WgpuSetup`, `egui_kittest` now prefers software rasterizers for testing [#5506](https://github.com/emilk/egui/pull/5506) by [@Wumpf](https://github.com/Wumpf)
* Write `.old.png` files when updating images [#5578](https://github.com/emilk/egui/pull/5578) by [@emilk](https://github.com/emilk)
* Succeed and keep going when `UPDATE_SNAPSHOTS` is set [#5649](https://github.com/emilk/egui/pull/5649) by [@emilk](https://github.com/emilk)


## 0.30.0 - 2024-12-16 - Initial relrease
* Support for egui 0.30.0
* Automate clicks and text input
* Automatic screenshot testing with wgpu
